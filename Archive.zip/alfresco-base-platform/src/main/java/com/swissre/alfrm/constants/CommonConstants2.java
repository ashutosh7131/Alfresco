package com.swissre.alfrm.constants;

import org.alfresco.service.namespace.QName;
import com.swissre.alfrm.model.*;

public class CommonConstants2 {

	public static final String SR_SITE_NAME = "swissre";
	public static final String SR_SITE_XPATH_QUERY = "./app:company_home/st:sites/cm:swissre/cm:documentLibrary";
	public static final String HYPHEN = "-";
	public static final String DOT = ".";

	public static final QName[] srModelProps = { SwissReModel.PROP_SR_GENERALDOC_LOCATION,
			SwissReModel.PROP_SR_GENERALDOC_Line_Of_Business };

}
