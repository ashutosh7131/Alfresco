(function() {

	YAHOO.Bubbling.fire("registerAction", {
		actionName: "onGenerateIndexAction",
		fn: function custom_DLTB_onExampleAction(assets) {
			var elementId = this.id + "-createAttribute",
				createAttributeDlg = new Alfresco.module.SimpleDialog(elementId);
			var noderef = assets.nodeRef;
			// This is a create scenario, attribute does not exist
			var keys = "create_attribute";		
			
			Alfresco.util.Ajax.jsonPost(
				{
					url: Alfresco.constants.PROXY_URI + "alfresco/createindexfileWebscript",
					responseContentType: "application/json",
					dataObj: assets,
					successMessage: this.msg("message.index-action.success"),
					failureMessage: this.msg("message.index-action.failure"),
					successCallback:
					{
						fn: function exampleSuccess() {
							console.log("Success");
						},
						scope: this
					},
					failureCallback:
					{
						fn: function exampleFailure() {
							console.log("Failure");
						},
						scope: this
					}
				});
		}
	});

})();